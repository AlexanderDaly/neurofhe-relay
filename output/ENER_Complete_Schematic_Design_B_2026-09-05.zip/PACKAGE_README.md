# ENER complete schematic design — revision B

Prepared September 5, 2026. This archive contains the complete reference design
using an existing acquisition device, Raspberry Pi local host, custom UP5K FPGA
relay circuit and a local/remote FHE software partition.

Start with:

1. output/pdf/ENER_Complete_Patent_Schematics.pdf — 16 patent figures.
2. output/pdf/ENER_Circuit_Schematics.pdf — eight component/datapath sheets.
3. output/pdf/ENER_Implementation_Design.pdf — 26-page implementation specification.

Editable sources, the 55-component BOM, all 226 pin assignments, KiCad import
files, SVG figures, FPGA hardware sources and verification evidence are under
patent/complete-design-2026-09-05/. Its README gives exact rebuild commands.
ENER_specification_with_reference_design.md is the separate patent working copy
with the matching figure descriptions and the new circuit embodiment.

The FPGA logic was simulated, synthesized and placed/routed. This archive is a
schematic and implementation design, not a fabricated board or validated headset
deployment. KiCad import/ERC and physical testing remain unperformed. The circuit
PDF and authoritative pin/net tables are available independently of KiCad.

Unzip into a new directory, preserving paths. The unchanged original specification
and minimal repository fixture sources are included for reproducibility, together
with the repository license. The complete original project is at:
https://github.com/AlexanderDaly/neurofhe-relay
Source commit: c42d68225934a3bfa46a4bdd7573d035ad907b96.

SHA256SUMS.txt lists checksums for every payload file (including this README).
ARCHIVE_MANIFEST.json records the same payload entries and their byte sizes.
The two inventory files intentionally do not hash themselves or one another.
